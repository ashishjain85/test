const path = require("path");
module.exports = {
  devtool: "source-map",
  mode: "development",
  entry: "./src/BasicComponent.tsx",
  output: {
    libraryTarget: "this",
    filename: "./bundle.js",
    path: path.join(__dirname, "build")
  },
  devServer: {
    static: {
      directory: path.join(__dirname, "/")
    },
    devMiddleware: {
      writeToDisk: true
    },
    port: 4200,
    liveReload: true,
    historyApiFallback: true,
    open: true
  },
  module: {
    rules: [
    // all files with a ".ts" or ".tsx" extension will be handled by "ts-loader"
      { test: /\.tsx?$/, loader: "ts-loader" }
    ]
  },
  resolve: {
    extensions: [".webpack.js", ".web.js", ".ts", ".js", ".tsx"]
  }
};
