import React from "react";
import { createRoot } from "react-dom/client";
import { SampleApp } from "./sample-app/react-ts-sample";

const container = document.getElementById("app");
const root = createRoot(container);

export default class BasicComponent extends React.Component <{}> {
  onLivenessCheckPressed(): void {
    SampleApp.onLivenessCheckPressed();
  }

  render(): any {
    return (
      <div>
        <div className="wrapping-box-container">
          <div id="controls" className="controls">
            <button id="liveness-button" className="big-button" onClick={ () => { return this.onLivenessCheckPressed(); } }>3D Liveness Check</button>
            <p id="status">Initializing...</p>
          </div>
          <div id="custom-logo-container">
            <img id="facetec-logo" src="../images/facetec_logo.png"/>
          </div>
        </div>
      </div>
    );
  }
}

root.render(
  (<BasicComponent tab="home" />)
);
